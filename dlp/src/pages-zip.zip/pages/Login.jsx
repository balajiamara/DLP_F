// src/pages/LoginPage.jsx
import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Login.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};

    if (!email) {
      newErrors.email = "Email is required";
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
      newErrors.email = "Enter a valid email address";
    }

    if (!password) {
      newErrors.password = "Password is required";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    // For now just log, no real authentication
    console.log("Login form submitted:", { email, password });
  };

  return (
    <div className="login-root">
      <div className="login-card">
        <div className="login-header">
          <h1 className="login-title">Daily Learning Planner</h1>
          <p className="login-subtitle">
            Sign in to track your goals and daily study progress.
          </p>
        </div>

        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {/* Email field */}
          <div className="form-group">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <div className="input-wrapper">
              {/* <span className="input-icon" aria-hidden="true">
                ✉️
              </span> */}
              <input
                id="email"
                type="email"
                className={`form-input ${errors.email ? "has-error" : ""}`}
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            {errors.email && <p className="error-text">{errors.email}</p>}
          </div>

          {/* Password field */}
          <div className="form-group">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <div className="input-wrapper">
              {/* <span className="input-icon" aria-hidden="true">
                🔒
              </span> */}
              <input
                id="password"
                type="password"
                className={`form-input ${errors.password ? "has-error" : ""}`}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {errors.password && (
              <p className="error-text">{errors.password}</p>
            )}
          </div>

          {/* Login button */}
          <button type="submit" className="login-button">
            Login
          </button>
        </form>

        <div className="login-footer">
          <p className="helper-text">
            New here?{" "}
            <Link to="/register" className="register-link">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
