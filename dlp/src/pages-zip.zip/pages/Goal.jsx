// src/pages/GoalForm.jsx
import React, { useState } from "react";
import "./Goal.css";

export default function Goal() {
  const [goal, setGoal] = useState({
    title: "",
    description: "",
    deadline: "",
    total_hours: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setGoal({ ...goal, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};
    if (!goal.title) newErrors.title = "Goal title is required";
    if (!goal.deadline) newErrors.deadline = "Deadline is required";
    if (!goal.total_hours) newErrors.total_hours = "Total hours required";
    else if (goal.total_hours < 1)
      newErrors.total_hours = "Hours must be a positive number";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    console.log("Goal created:", goal);
  };

  return (
    <div className="goal-root">
      <div className="goal-card">
        <h1 className="goal-title">Create Learning Goal</h1>
        <p className="goal-subtitle">
          Add your learning objectives and track progress easily.
        </p>

        <form className="goal-form" onSubmit={handleSubmit} noValidate>
          {/* Title */}
          <div className="form-group">
            <label className="form-label">Goal Title</label>
            <input
              type="text"
              name="title"
              placeholder="e.g., Learn JavaScript"
              className={`form-input ${errors.title ? "has-error" : ""}`}
              value={goal.title}
              onChange={handleChange}
            />
            {errors.title && <p className="error-text">{errors.title}</p>}
          </div>

          {/* Description */}
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              name="description"
              placeholder="Write a short description..."
              className="form-textarea"
              value={goal.description}
              onChange={handleChange}
            />
          </div>

          {/* Deadline */}
          <div className="form-group">
            <label className="form-label">Deadline</label>
            <input
              type="date"
              name="deadline"
              className={`form-input ${errors.deadline ? "has-error" : ""}`}
              value={goal.deadline}
              onChange={handleChange}
            />
            {errors.deadline && <p className="error-text">{errors.deadline}</p>}
          </div>

          {/* Total Hours */}
          <div className="form-group">
            <label className="form-label">Total Hours Needed</label>
            <input
              type="number"
              name="total_hours"
              placeholder="e.g., 20"
              className={`form-input ${
                errors.total_hours ? "has-error" : ""
              }`}
              value={goal.total_hours}
              onChange={handleChange}
            />
            {errors.total_hours && (
              <p className="error-text">{errors.total_hours}</p>
            )}
          </div>

          {/* Submit Button */}
          <button type="submit" className="goal-button">
            Save Goal
          </button>
        </form>
      </div>
    </div>
  );
}
