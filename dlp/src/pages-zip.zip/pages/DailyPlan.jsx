// src/pages/DailyPlanForm.jsx
import React, { useState } from "react";
import "./DailyPlan.css";

/**
 * Optional:
 * You can pass `goals` as a prop = [{ id, title }, ...]
 * For now, we'll keep a simple static example list.
 */
const sampleGoals = [
  { id: 1, title: "Python Basics" },
  { id: 2, title: "SQL Fundamentals" },
  { id: 3, title: "React Beginner" },
];

export default function DailyPlan({ goals = sampleGoals }) {
  const [plan, setPlan] = useState({
    goal_id: "",
    date: "",
    topics: "",
    planned_hours: "",
    is_completed: false,
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPlan({
      ...plan,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const validate = () => {
    const newErrors = {};

    if (!plan.date) newErrors.date = "Date is required";
    if (!plan.topics) newErrors.topics = "Topics are required";

    if (!plan.planned_hours) {
      newErrors.planned_hours = "Planned hours are required";
    } else if (Number(plan.planned_hours) < 1) {
      newErrors.planned_hours = "Hours must be at least 1";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    console.log("Daily plan created:", plan);
  };

  return (
    <div className="daily-root">
      <div className="daily-card">
        <h1 className="daily-title">Create Daily Learning Plan</h1>
        <p className="daily-subtitle">
          Plan what you’ll study today and how long you’ll focus.
        </p>

        <form className="daily-form" onSubmit={handleSubmit} noValidate>
          {/* Goal (optional) */}
          <div className="form-group">
            <label className="form-label">Linked Goal (Optional)</label>
            <select
              name="goal_id"
              className="form-input"
              value={plan.goal_id}
              onChange={handleChange}
            >
              <option value="">No goal linked</option>
              {goals.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.title}
                </option>
              ))}
            </select>
          </div>

          {/* Date */}
          <div className="form-group">
            <label className="form-label">Date</label>
            <input
              type="date"
              name="date"
              className={`form-input ${errors.date ? "has-error" : ""}`}
              value={plan.date}
              onChange={handleChange}
            />
            {errors.date && <p className="error-text">{errors.date}</p>}
          </div>

          {/* Topics */}
          <div className="form-group">
            <label className="form-label">Topics</label>
            <textarea
              name="topics"
              placeholder="e.g., Lists, Tuples, Sets basics"
              className={`form-textarea ${errors.topics ? "has-error" : ""}`}
              value={plan.topics}
              onChange={handleChange}
            />
            {errors.topics && <p className="error-text">{errors.topics}</p>}
            <p className="helper-note">
              You can enter comma-separated topics or a short description.
            </p>
          </div>

          {/* Planned Hours */}
          <div className="form-group">
            <label className="form-label">Planned Hours</label>
            <input
              type="number"
              name="planned_hours"
              placeholder="e.g., 2"
              className={`form-input ${
                errors.planned_hours ? "has-error" : ""
              }`}
              value={plan.planned_hours}
              onChange={handleChange}
            />
            {errors.planned_hours && (
              <p className="error-text">{errors.planned_hours}</p>
            )}
          </div>

          {/* Completed checkbox */}
          <div className="form-group checkbox-row">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="is_completed"
                checked={plan.is_completed}
                onChange={handleChange}
              />
              <span>Mark as completed</span>
            </label>
          </div>

          {/* Submit */}
          <button type="submit" className="daily-button">
            Save Daily Plan
          </button>
        </form>
      </div>
    </div>
  );
}
