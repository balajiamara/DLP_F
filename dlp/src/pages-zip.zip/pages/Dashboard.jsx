// src/pages/Dashboard.jsx
import React from "react";
import "./Dashboard.css";

export default function Dashboard() {
  // Dummy data for now – later replace with real API data
  const user = {
    name: "Balaji",
    email: "balaji@example.com",
  };

  const todaysPlan = [
    {
      id: 1,
      goalTitle: "Python Basics",
      topics: ["Lists & Tuples", "Sets basics", "If/Else revision"],
      plannedHours: 2,
      completed: 1, // topics completed
      totalTopics: 3,
    },
    {
      id: 2,
      goalTitle: "SQL Fundamentals",
      topics: ["SELECT & WHERE", "ORDER BY & LIMIT"],
      plannedHours: 1.5,
      completed: 0,
      totalTopics: 2,
    },
  ];

  const goals = [
    {
      id: 1,
      title: "Complete Python Basics",
      deadline: "2025-12-05",
      status: "In Progress",
      progress: 60,
    },
    {
      id: 2,
      title: "Master SQL Queries",
      deadline: "2025-12-10",
      status: "In Progress",
      progress: 40,
    },
    {
      id: 3,
      title: "React Fundamentals",
      deadline: "2025-12-20",
      status: "Not Started",
      progress: 10,
    },
  ];

  const weeklyProgress = {
    hoursPlanned: 10,
    hoursCompleted: 6,
  };

  const weeklyPercent = Math.round(
    (weeklyProgress.hoursCompleted / weeklyProgress.hoursPlanned) * 100
  );

  const aiHint =
    "You are close to finishing 'Python Basics'. Tomorrow, focus on practice problems for loops and functions.";

  const handleLogout = () => {
    console.log("Logout clicked");
    // Later: clear auth & redirect
  };

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <div className="dash-root">
      <div className="dash-container">
        {/* ===== Top Bar ===== */}
        <header className="dash-header">
          <div className="dash-greeting">
            <p className="dash-greeting-label">Welcome back,</p>
            <h1 className="dash-greeting-title">
              {user.name} 👋
            </h1>
            <p className="dash-greeting-subtitle">
              Today is <span className="pill pill-date">{today}</span>.  
              Stay consistent and your goals will follow.
            </p>
          </div>

          <div className="dash-user-card">
            <div className="dash-user-info">
              <div className="dash-avatar">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="dash-user-name">{user.name}</p>
                <p className="dash-user-email">{user.email}</p>
              </div>
            </div>
            <button className="dash-logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </header>

        {/* ===== Main Grid ===== */}
        <main className="dash-main">
          <section className="dash-card dash-today">
            <div className="dash-card-header">
              <h2>Today&apos;s Plan</h2>
              <button className="ghost-btn">+ Add Plan</button>
            </div>
            <p className="dash-card-subtitle">
              Focus on what matters most today. Mark topics as you complete them.
            </p>

            <div className="today-list">
              {todaysPlan.map((plan) => {
                const percent = Math.round(
                  (plan.completed / plan.totalTopics) * 100
                );
                return (
                  <div key={plan.id} className="today-item">
                    <div className="today-item-header">
                      <div className="today-item-goal">
                        <span className="today-goal-pill">
                          {plan.goalTitle}
                        </span>
                        <span className="today-hours">
                          {plan.plannedHours} hrs
                        </span>
                      </div>
                      <span className="today-progress-label">
                        {plan.completed}/{plan.totalTopics} done
                      </span>
                    </div>

                    <div className="today-topics">
                      {plan.topics.map((topic, idx) => (
                        <div key={idx} className="topic-pill">
                          <span className="topic-dot" />
                          <span>{topic}</span>
                        </div>
                      ))}
                    </div>

                    <div className="today-progress-bar">
                      <div
                        className="today-progress-fill"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="dash-card dash-goals">
            <div className="dash-card-header">
              <h2>Goals & Deadlines</h2>
              <button className="ghost-btn">Manage Goals</button>
            </div>
            <p className="dash-card-subtitle">
              Keep an eye on your upcoming deadlines and overall progress.
            </p>

            <div className="goals-list">
              {goals.map((goal) => (
                <div key={goal.id} className="goal-item">
                  <div className="goal-main">
                    <p className="goal-title">{goal.title}</p>
                    <p className="goal-deadline">
                      Due: <span>{goal.deadline}</span>
                    </p>
                  </div>
                  <div className="goal-meta">
                    <span
                      className={`status-pill status-${goal.status
                        .toLowerCase()
                        .replace(" ", "-")}`}
                    >
                      {goal.status}
                    </span>
                    <div className="goal-progress">
                      <div
                        className="goal-progress-fill"
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                    <span className="goal-progress-text">
                      {goal.progress}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>

        {/* ===== Bottom Row ===== */}
        <section className="dash-bottom">
          <div className="dash-card dash-progress">
            <div className="dash-card-header">
              <h2>Weekly Progress</h2>
            </div>
            <p className="dash-card-subtitle">
              You&apos;re building consistency. Keep your streak alive!
            </p>

            <div className="progress-summary">
              <div className="progress-numbers">
                <div>
                  <p className="progress-label">Planned</p>
                  <p className="progress-value">
                    {weeklyProgress.hoursPlanned} hrs
                  </p>
                </div>
                <div>
                  <p className="progress-label">Completed</p>
                  <p className="progress-value">
                    {weeklyProgress.hoursCompleted} hrs
                  </p>
                </div>
                <div>
                  <p className="progress-label">Completion</p>
                  <p className="progress-value">{weeklyPercent}%</p>
                </div>
              </div>

              <div className="progress-bar">
                <div
                  className="progress-bar-fill"
                  style={{ width: `${weeklyPercent}%` }}
                />
              </div>
            </div>
          </div>

          <div className="dash-card dash-ai">
            <div className="dash-card-header">
              <h2>AI Study Suggestions</h2>
              <span className="pill pill-ai">Smart Tips</span>
            </div>
            <p className="dash-card-subtitle">
              Powered by your goals and recent activity.
            </p>

            <p className="ai-text">{aiHint}</p>

            <div className="ai-actions">
              <button className="primary-btn">Open AI Planner</button>
              <button className="ghost-btn subtle">Refresh Suggestion</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
